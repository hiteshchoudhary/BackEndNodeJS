const express = require("express");
const mongoose = require("mongoose");

const app = express();

//mongoDB configuration
const db = require("./setup/myurl").mongoURL;

//Attempt to connect to database
mongoose
  .connect(db)
  .then(() => console.log("MongoDB connected successfully"))
  .catch(err => console.log(err));

//route
app.get("/", (req, res) => {
  res.send("Hey there Big stack");
});

const port = process.env.PORT || 3000;

app.listen(port, () => console.log(`App is running at ${port}`));
