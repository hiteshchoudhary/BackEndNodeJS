module.exports = {
  mongoURL: "mongodb://hitesh:hitesh123@ds161610.mlab.com:61610/lcocourse",
  secret: "mystrongsecret"
};
